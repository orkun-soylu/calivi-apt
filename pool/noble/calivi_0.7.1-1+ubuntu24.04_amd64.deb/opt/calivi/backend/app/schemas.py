import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class RegisterIn(BaseModel):
    email: str
    username: str
    password: str
    # Appliance only (host_bootstrap.py): the first registration claims the machine.
    setup_code: str | None = None
    hostname: str | None = None
    timezone: str | None = None
    ssh_key: str | None = None


class LoginIn(BaseModel):
    identifier: str  # email or username
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    email: str
    username: str
    role: str
    blocked: bool = False
    created_at: datetime.datetime


class MeOut(UserOut):
    """The signed-in user, plus what the UI needs to know about their own capabilities."""

    host_tools: bool = False  # the host's shell is available to this user (calivi-vm owner)


class UserUpdate(BaseModel):
    # Partial admin update: only the fields actually sent are applied.
    email: str | None = None
    username: str | None = None
    role: str | None = None  # "admin" | "user"
    blocked: bool | None = None


class AuthConfigOut(BaseModel):
    registration_enabled: bool
    host_setup: bool = False  # the next registration claims this machine (needs the setup code)


class SettingsUpdate(BaseModel):
    registration_enabled: bool | None = None


class AttachmentIn(BaseModel):
    name: str
    text: str  # extracted document text (injected into the model's context)


class AttachmentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    name: str  # shown as a chip in the UI
    # What a tool returned, for the inspection panel. `text` stays out: on a document
    # attachment it holds the whole extracted file, which would be re-sent on every chat load
    # for no purpose. `detail` is clipped at MAX_DETAIL_CHARS and is the only reason the panel
    # can exist — omitting it here silently disabled the feature while the data sat in the DB.
    detail: str | None = None


class ServerCreate(BaseModel):
    name: str
    type: str = "ollama"  # "ollama" | "openai"
    host: str = ""  # ollama
    port: int = 11434  # ollama
    base_url: str | None = None  # openai
    api_key: str | None = None  # openai


class ServerUpdate(BaseModel):
    # Partial update: only fields that were explicitly set are applied.
    # Omitting api_key keeps the existing key (exclude_unset).
    name: str | None = None
    type: str | None = None
    host: str | None = None
    port: int | None = None
    base_url: str | None = None
    api_key: str | None = None


class ServerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    type: str = "ollama"
    host: str | None = None
    port: int
    base_url: str | None = None
    has_api_key: bool = False  # the key itself is never returned
    status: str = "unknown"  # "up" | "down"
    models: list[str] = []
    vision_models: list[str] = []  # subset of models: those supporting images (vision)
    image_models: list[str] = []  # subset of models: those that generate images (/images/generations)


class McpServerCreate(BaseModel):
    name: str
    url: str
    transport: str = "http"  # "http" (Streamable HTTP) | "sse" (older HTTP+SSE)
    secret: str | None = None
    secret_header: str = "Authorization"
    secret_prefix: str = "Bearer "
    headers: dict[str, str] | None = None
    enabled: bool = True
    tool_modes: dict[str, str] | None = None


class McpServerUpdate(BaseModel):
    # Partial update: only explicitly set fields are applied. Omitting `secret` keeps the
    # stored one (exclude_unset) — the same contract as ServerUpdate.api_key.
    name: str | None = None
    url: str | None = None
    transport: str | None = None
    secret: str | None = None
    secret_header: str | None = None
    secret_prefix: str | None = None
    headers: dict[str, str] | None = None
    enabled: bool | None = None
    tool_modes: dict[str, str] | None = None


class McpToolOut(BaseModel):
    name: str  # the namespaced registry name
    raw_name: str = ""  # the server's own name — sent so the UI never re-parses the namespace
    description: str = ""
    read_only: bool = False
    mode: str = "auto"  # "off" | "auto" | "approve"


class McpServerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    url: str
    transport: str = "http"
    has_secret: bool = False  # the secret itself is never returned
    secret_header: str = "Authorization"
    secret_prefix: str = "Bearer "
    headers: dict[str, str] = {}
    enabled: bool = True
    tool_modes: dict[str, str] = {}
    status: str = "unknown"  # "up" | "down" | "disabled"
    error: str | None = None  # why it is down — shown as a tooltip in Settings
    tools: list[McpToolOut] = []  # every discovered tool, with its mode


class RuleIn(BaseModel):
    kind: str
    pattern: str


class ApprovalDecision(BaseModel):
    approved: bool
    # "Always allow…" on the card (#113): save this rule, then approve. Only with approved=True.
    rule: RuleIn | None = None


class ChatCreate(BaseModel):
    title: str = "New Chat"
    mode: Literal["chat", "agent"] | None = None  # None → agent on calivi-vm, chat elsewhere


class ChatOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    pinned: bool = False
    mode: str = "chat"
    created_at: datetime.datetime
    updated_at: datetime.datetime


class ChatUpdate(BaseModel):
    title: str | None = None
    pinned: bool | None = None
    context_mode: Literal["compact", "full"] | None = None
    mode: Literal["chat", "agent"] | None = None


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    role: str
    content: str
    images: list[str] | None = None  # list of base64 data-URIs (images on a user message)
    attachments: list[AttachmentOut] | None = None  # document attachments (name only is returned)
    model_used: str | None
    server_used: str | None
    tokens_per_sec: float | None = None
    steps: list[dict] | None = None  # agent mode: the reply's tool steps (outputs are untrusted text)
    plan: dict | None = None  # plan mode (#114): the proposed plan and its status
    timestamp: datetime.datetime


class ChatDetailOut(ChatOut):
    messages: list[MessageOut] = []
    # Compaction (compaction.py). The summary is returned so the user can read what the model
    # is working from; the estimate is chars/4 of what the current mode would send.
    summary: str | None = None
    summary_upto_id: int | None = None
    context_mode: str = "compact"
    context_tokens_estimate: int = 0
    compact_suggest_tokens: int = 0
    compactable: bool = False
    compact_suggested: bool = False
    active_turn: bool = False  # a reply is still running; the UI re-attaches (GET …/turn)


class CompactIn(BaseModel):
    server_id: int | None = None
    model: str | None = None


class ImageOptions(BaseModel):
    """Settings for a turn on an image-generation model (the 🎨 picker). Unset → the server's default.
    `steps` and `seed` are not in OpenAI's API; they are sent only when set."""
    size: str | None = Field(None, pattern=r"^[1-9][0-9]{1,4}x[1-9][0-9]{1,4}$")
    steps: int | None = Field(None, ge=1, le=150)
    seed: int | None = Field(None, ge=0, le=2**63 - 1)


class SendMessageIn(BaseModel):
    content: str
    images: list[str] = []  # base64 data-URI listesi (vision)
    attachments: list[AttachmentIn] = []  # document attachments (extracted text)
    server_id: int | None = None  # None → chosen by the caller
    model: str | None = None  # None → chosen by the caller (on server_id if given)
    use_tools: bool = False  # when on, the tool layer is offered to the model (it decides what to call)
    ask_every_tool: bool = False  # when on, every tool call waits for the user's approval
    plan_mode: bool = False  # 📋 (#114): the model may only inspect, then proposes a plan
    run_plan: int | None = None  # the id of the reply whose plan the owner approves with this turn
    image_options: ImageOptions | None = None  # image models only


class EditMessageIn(BaseModel):
    content: str
    images: list[str] | None = None  # None → existing images are kept
    server_id: int | None = None
    model: str | None = None
    use_tools: bool = False
    ask_every_tool: bool = False
    plan_mode: bool = False
    image_options: ImageOptions | None = None  # image models only


class ForkIn(BaseModel):
    message_id: int
    content: str
    images: list[str] = []
    attachments: list[AttachmentIn] = []
    server_id: int | None = None
    model: str | None = None
    use_tools: bool = False
    ask_every_tool: bool = False
    plan_mode: bool = False
    image_options: ImageOptions | None = None  # image models only
